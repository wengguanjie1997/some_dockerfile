docker build $1 -t rsyslog/rsyslog_dev_buildbot_suse:tumbleweed .
echo ready to run:    docker push rsyslog/rsyslog_dev_buildbot_suse:tumbleweed
