docker build $1 -t rsyslog/rsyslog_dev_buildbot_fedora:31 .
