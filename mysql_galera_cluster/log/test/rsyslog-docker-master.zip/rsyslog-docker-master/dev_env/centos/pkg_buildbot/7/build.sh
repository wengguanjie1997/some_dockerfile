docker build $1 -t rsyslog/rsyslog_dev_pkg_buildbot_centos:7 .
