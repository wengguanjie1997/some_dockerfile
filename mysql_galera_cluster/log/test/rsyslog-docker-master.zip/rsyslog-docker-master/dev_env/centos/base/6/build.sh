docker build $1 -t rsyslog/rsyslog_dev_base_centos:6 .
