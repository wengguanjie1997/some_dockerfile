docker build $1 -t rsyslog/rsyslog_dev_buildbot_ubuntu-arm:18.04 .
echo ready too run docker push rsyslog/rsyslog_dev_buildbot_ubuntu-arm:18.04
