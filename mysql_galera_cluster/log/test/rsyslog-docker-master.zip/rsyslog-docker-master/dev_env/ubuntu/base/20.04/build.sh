docker build $1 -t rsyslog/rsyslog_dev_base_ubuntu:20.04 .
