docker tag rsyslog/rsyslog_dev_base_ubuntu-arm:18.04 rsyslog/rsyslog_dev_base_ubuntu-arm:18.04_previous
docker push rsyslog/rsyslog_dev_base_ubuntu-arm:18.04_previous
