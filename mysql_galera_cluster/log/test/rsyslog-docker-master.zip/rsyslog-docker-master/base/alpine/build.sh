docker build $* -t rsyslog/rsyslog_base_alpine:latest .
