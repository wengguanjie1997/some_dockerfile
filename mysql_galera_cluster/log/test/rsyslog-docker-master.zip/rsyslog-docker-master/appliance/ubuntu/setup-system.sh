apk update
apk upgrade
apk add git build-base automake libtool autoconf py-docutils gnutls gnutls-dev \
	zlib-dev curl-dev mysql-dev libdbi-dev libuuid util-linux-dev \
	libgcrypt-dev flex bison bsd-compat-headers linux-headers valgrind

# interactive dev only:
# apk add man man-pages gcc-doc
