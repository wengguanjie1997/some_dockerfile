docker build $* -t rsyslog/syslog_appliance_alpine:latest .
